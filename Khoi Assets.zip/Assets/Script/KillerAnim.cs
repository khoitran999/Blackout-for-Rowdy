using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillerAnim : MonoBehaviour
{
    public Killer script;
    Animator anim;
    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
        if (anim == null)
    {
        Debug.LogError("Animator component not found!");
    }

    }
        
    

    void Update()
    {   
        if(script.movingHorizontal==true)
        {
            anim.SetTrigger("Walk");
        } else if(script.movingVerticle==true)
        {
            print("going up");
            anim.SetTrigger("GoUp");
        }
        else
        {
            anim.SetTrigger("GoIdle");
        }
      
    }
}
