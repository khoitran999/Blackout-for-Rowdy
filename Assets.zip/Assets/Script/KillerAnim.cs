using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillerAnim : MonoBehaviour
{
    public Killer script;
    private Animator anim;

    private float timeBtwAttack = 6f;
    private float startTimeBtwAttack = 0f;

    public Transform attackPos;
    public float attackRange;
    public LayerMask playerHitbox;
    public int damage;

    bool attacking;

    private void Start()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    void Update()
    {
        
        //else
        //{
        //    anim.SetTrigger("GoIdle");
        //}

        //if 
        
        if (Input.GetKey("g") && timeBtwAttack > 3)
        {
            
            anim.SetTrigger("Attack");
            //reset timeBtwkAttack
            timeBtwAttack = startTimeBtwAttack;
            

            Collider2D[] enemiesToDamage = Physics2D.OverlapCircleAll(attackPos.position, attackRange, playerHitbox);
            for (int i = 0; i < enemiesToDamage.Length; i++)
            {
                enemiesToDamage[i].GetComponent<Player>().TakeDamage(damage);
            }
            
        }
        else if (script.movingHorizontal == true)
        {
            anim.SetTrigger("Walk");
        }
        else if (script.movingVerticle == true)
        {
            //print("going up");
            anim.SetTrigger("GoUp");
        }


        else
        {
            timeBtwAttack += Time.deltaTime;
            print(timeBtwAttack);
            //if (timeBtwAttack > 4)
            //{
            //    anim.SetTrigger("GoIdle");
            //}
        }

        
    }
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPos.position, attackRange);
    }
}
