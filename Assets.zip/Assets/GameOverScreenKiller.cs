using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverScreenKiller : MonoBehaviour
{

    public void Setup()
    {
        gameObject.SetActive(true);
    }
}
